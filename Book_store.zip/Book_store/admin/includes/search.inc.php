<ul>
			<li id="search">
				<h2>Search</h2>
				<form method="get" action="">
					<fieldset>
					<input type="text" id="s" name="s" value="" />
					<input type="submit" id="x" value="Search" />
					</fieldset>
				</form>
			</li>
			<li>
				<h2>Categories</h2>
				<ul>
					<li><a href="#">Architecture</a></li>
					<li><a href="#">Art And Culture</a></li>
					<li><a href="#">Forest</a></li>
					<li><a href="#">Sports</a></li>
					<li><a href="#">Astrology</a></li>
					<li><a href="#">Business</a></li>
					<li><a href="#">Low Books</a></li>
					<li><a href="#">Tourism</a></li>
					<li><a href="#">Yoga</a></li>
					<li><a href="#">Management</a></li>
					<li><a href="#">Terrorism</a></li>
					<li><a href="#">Tracking</a></li>
					<li><a href="#">Fiction</a></li>
					<li><a href="#">Cooking</a></li>
					<li><a href="#">Compititive Exam</a></li>
					<li><a href="#">tess</a></li>
                    <li><a href="#">Computer</a></li>
					<li><a href="#">History</a></li>
					<li><a href="#">Travelling</a></li>
					<li><a href="#">Economics</a></li>
					<li><a href="#">Comics</a></li>
					<li><a href="#">Religion</a></li>
					<li><a href="#">Commerce</a></li>
					<li><a href="#">Science</a></li>
				</ul>
			</li>
			
		</ul>