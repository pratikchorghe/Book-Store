<?php session_start();?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <?php
            include("includes/head.inc.php");
        ?>
<script type="text/javascript">alert("Your Order has been successfully Placed...\n Thank You for Purchasing.");location="index.php";
</script>
</head>  
</html>

    
?>